#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

long long solve(long long N, long long R, long long C) {
	// insert your code here
	return 42;
}

int main() {
    long long N, R, C;
    assert(3 == scanf("%lld %lld %lld", &N, &R, &C));
    printf("%lld\n", solve(N, R, C));
    return 0;
}

